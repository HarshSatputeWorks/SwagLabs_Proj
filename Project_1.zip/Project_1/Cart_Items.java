package Project_1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Cart_Items extends Utility {
	Repository rep = new Repository();
	String exp_prod_name = "Sauce Labs Bike Light";

	@BeforeClass
	public void open() {
		open_browser("chrome");
		open_url("https://www.saucedemo.com/");
		driver.findElement(rep.swag_id).sendKeys("standard_user");
		driver.findElement(rep.swag_pw).sendKeys("secret_sauce");
		driver.findElement(rep.swag_login).click();

	}

	@AfterClass
	public void close() {
		Actions x = new Actions(driver);
		driver.findElement(By.id("react-burger-menu-btn")).click();
		WebElement sidemenu = driver
				.findElement(By.xpath("/html/body/div/div/div/div[1]/div[1]/div[1]/div/div[1]/div/button"));
		WebElement LogOut = driver.findElement(By.id("logout_sidebar_link"));
		x.moveToElement(sidemenu).click(LogOut).build().perform();
		close_browser();
	}

	@Test
	public void Items() {
		driver.findElement(By.id("add-to-cart-sauce-labs-bike-light")).click();
		driver.findElement(By.xpath("/html/body/div/div/div/div[1]/div[1]/div[3]/a")).click();
		System.out.println(exp_prod_name);
		String actual_prod_name = driver
				.findElement(By.xpath("/html/body/div/div/div/div[2]/div/div[1]/div[3]/div[2]/a/div")).getText();
		try {
			Assert.assertEquals(actual_prod_name, exp_prod_name);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
