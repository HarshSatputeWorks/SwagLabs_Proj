package Project_1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class HomePage extends Utility {
	Repository rep = new Repository();
	String exp_prod_name = "Sauce Labs Backpack";

	@BeforeClass
	public void open() {
		open_browser("chrome");
		open_url("https://www.saucedemo.com/");
		driver.findElement(rep.swag_id).sendKeys("standard_user");
		driver.findElement(rep.swag_pw).sendKeys("secret_sauce");
		driver.findElement(rep.swag_login).click();

	}

	@AfterClass
	public void close() {
		Actions x = new Actions(driver);
		driver.findElement(By.id("react-burger-menu-btn")).click();
		WebElement sidemenu = driver
				.findElement(By.xpath("/html/body/div/div/div/div[1]/div[1]/div[1]/div/div[1]/div/button"));
		WebElement LogOut = driver.findElement(By.id("logout_sidebar_link"));
		x.moveToElement(sidemenu).click(LogOut).build().perform();
		close_browser();
	}

	@Test
	public void Prod_Verif() {
		driver.findElement(By.xpath("/html/body/div[1]/div/div/div[2]/div/div/div/div[1]/div[2]/div[1]/a/div")).click();
		String actual_prod_name = driver.findElement(By.xpath("/html/body/div[1]/div/div/div[2]/div/div/div[2]/div[1]"))
				.getText();
		System.out.println(exp_prod_name);
		System.out.println(actual_prod_name);
		try {
			Assert.assertEquals(actual_prod_name, exp_prod_name);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
