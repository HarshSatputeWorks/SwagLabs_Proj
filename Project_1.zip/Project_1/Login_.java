package Project_1;

import org.openqa.selenium.By;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Login_ extends Utility {

	@BeforeClass
	public void open() {
		open_browser("chrome");
	}

	@AfterClass
	public void close() {
		close_browser();
	}

	@Test
	public void Error_Msg() {
		String Expected = "Epic sadface: Username and password do not match any user in this service";
		driver.get("https://www.saucedemo.com/");
		driver.findElement(By.id("user-name")).sendKeys("secret_sauce");
		driver.findElement(By.id("password")).sendKeys("secret_sauce");
		driver.findElement(By.id("login-button")).click();
		String Actual = driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div/div/form/div[3]/h3"))
				.getText();
		try {
			Assert.assertEquals(Actual, Expected);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	@Test(dataProvider = "testname_1")
	public void data(String username, String password) {
		String Ex = "https://www.saucedemo.com/inventory.html";
		driver.get("https://www.saucedemo.com/");
		driver.findElement(By.id("user-name")).sendKeys(username);
		driver.findElement(By.id("password")).sendKeys(password);
		driver.findElement(By.id("login-button")).click();
		String Act = driver.getCurrentUrl();
		try {
			Assert.assertEquals(Act, Ex);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@DataProvider(name = "testname_1")
	public Object[][] dpmeth() {
		return new Object[][] {

				{ "standard_user", "secret_sauce" } };
	}
}
