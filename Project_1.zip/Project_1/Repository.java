package Project_1;

import org.openqa.selenium.By;

public class Repository {
	By swag_id = By.id("user-name");
	By swag_pw = By.id("password");
	By swag_login = By.id("login-button");
}
